package com.un.yuancoin.server.dao.trade.recommend;

import com.un.yuancoin.model.recommend.Recommend;

public interface RecommendMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Recommend record);

    int insertSelective(Recommend record);

    Recommend selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Recommend record);

    int updateByPrimaryKey(Recommend record);
}