package com.un.yuancoin.model.tranCancelOrder;

import java.math.BigDecimal;
import java.util.Date;

public class TranCancelOrder {
    private Long id;

    private Long financeAccountId;

    private Long entrustId;

    private BigDecimal amount;

    private BigDecimal tradeAmount;

    private BigDecimal untradeAmount;

    private Long orderStatus;

    private Date createdate;

    private String tranSequence;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFinanceAccountId() {
        return financeAccountId;
    }

    public void setFinanceAccountId(Long financeAccountId) {
        this.financeAccountId = financeAccountId;
    }

    public Long getEntrustId() {
        return entrustId;
    }

    public void setEntrustId(Long entrustId) {
        this.entrustId = entrustId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getTradeAmount() {
        return tradeAmount;
    }

    public void setTradeAmount(BigDecimal tradeAmount) {
        this.tradeAmount = tradeAmount;
    }

    public BigDecimal getUntradeAmount() {
        return untradeAmount;
    }

    public void setUntradeAmount(BigDecimal untradeAmount) {
        this.untradeAmount = untradeAmount;
    }

    public Long getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Long orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public String getTranSequence() {
        return tranSequence;
    }

    public void setTranSequence(String tranSequence) {
        this.tranSequence = tranSequence == null ? null : tranSequence.trim();
    }
}