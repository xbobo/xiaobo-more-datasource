package com.un.yuancoin.server.dao.trade.friendlyLink;

import com.un.yuancoin.model.friendlyLink.FriendlyLink;

public interface FriendlyLinkMapper {
    int deleteByPrimaryKey(Long id);

    int insert(FriendlyLink record);

    int insertSelective(FriendlyLink record);

    FriendlyLink selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(FriendlyLink record);

    int updateByPrimaryKey(FriendlyLink record);
}