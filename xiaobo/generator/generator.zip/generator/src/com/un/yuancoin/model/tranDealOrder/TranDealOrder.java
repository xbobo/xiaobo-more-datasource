package com.un.yuancoin.model.tranDealOrder;

import java.math.BigDecimal;
import java.util.Date;

public class TranDealOrder {
    private Long id;

    private Long buyTargetFinanceAccountId;

    private Long saleTargetFinanceAccountId;

    private Long entrustId;

    private Long beentrustId;

    private Long sourceCoinId;

    private Long targetCoinId;

    private BigDecimal price;

    private BigDecimal amount;

    private BigDecimal buyFeeAmount;

    private BigDecimal saleFeeAmount;

    private Date createdate;

    private String saleTranSequence;

    private String buyTranSequence;

    private Long buySourceFinanceAccountId;

    private Long saleSourceFinanceAccountId;

    private Long buyAccountId;

    private String buyAccountName;

    private Long saleAccountId;

    private String saleAccountName;

    private Long tradeMode;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBuyTargetFinanceAccountId() {
        return buyTargetFinanceAccountId;
    }

    public void setBuyTargetFinanceAccountId(Long buyTargetFinanceAccountId) {
        this.buyTargetFinanceAccountId = buyTargetFinanceAccountId;
    }

    public Long getSaleTargetFinanceAccountId() {
        return saleTargetFinanceAccountId;
    }

    public void setSaleTargetFinanceAccountId(Long saleTargetFinanceAccountId) {
        this.saleTargetFinanceAccountId = saleTargetFinanceAccountId;
    }

    public Long getEntrustId() {
        return entrustId;
    }

    public void setEntrustId(Long entrustId) {
        this.entrustId = entrustId;
    }

    public Long getBeentrustId() {
        return beentrustId;
    }

    public void setBeentrustId(Long beentrustId) {
        this.beentrustId = beentrustId;
    }

    public Long getSourceCoinId() {
        return sourceCoinId;
    }

    public void setSourceCoinId(Long sourceCoinId) {
        this.sourceCoinId = sourceCoinId;
    }

    public Long getTargetCoinId() {
        return targetCoinId;
    }

    public void setTargetCoinId(Long targetCoinId) {
        this.targetCoinId = targetCoinId;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getBuyFeeAmount() {
        return buyFeeAmount;
    }

    public void setBuyFeeAmount(BigDecimal buyFeeAmount) {
        this.buyFeeAmount = buyFeeAmount;
    }

    public BigDecimal getSaleFeeAmount() {
        return saleFeeAmount;
    }

    public void setSaleFeeAmount(BigDecimal saleFeeAmount) {
        this.saleFeeAmount = saleFeeAmount;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public String getSaleTranSequence() {
        return saleTranSequence;
    }

    public void setSaleTranSequence(String saleTranSequence) {
        this.saleTranSequence = saleTranSequence == null ? null : saleTranSequence.trim();
    }

    public String getBuyTranSequence() {
        return buyTranSequence;
    }

    public void setBuyTranSequence(String buyTranSequence) {
        this.buyTranSequence = buyTranSequence == null ? null : buyTranSequence.trim();
    }

    public Long getBuySourceFinanceAccountId() {
        return buySourceFinanceAccountId;
    }

    public void setBuySourceFinanceAccountId(Long buySourceFinanceAccountId) {
        this.buySourceFinanceAccountId = buySourceFinanceAccountId;
    }

    public Long getSaleSourceFinanceAccountId() {
        return saleSourceFinanceAccountId;
    }

    public void setSaleSourceFinanceAccountId(Long saleSourceFinanceAccountId) {
        this.saleSourceFinanceAccountId = saleSourceFinanceAccountId;
    }

    public Long getBuyAccountId() {
        return buyAccountId;
    }

    public void setBuyAccountId(Long buyAccountId) {
        this.buyAccountId = buyAccountId;
    }

    public String getBuyAccountName() {
        return buyAccountName;
    }

    public void setBuyAccountName(String buyAccountName) {
        this.buyAccountName = buyAccountName == null ? null : buyAccountName.trim();
    }

    public Long getSaleAccountId() {
        return saleAccountId;
    }

    public void setSaleAccountId(Long saleAccountId) {
        this.saleAccountId = saleAccountId;
    }

    public String getSaleAccountName() {
        return saleAccountName;
    }

    public void setSaleAccountName(String saleAccountName) {
        this.saleAccountName = saleAccountName == null ? null : saleAccountName.trim();
    }

    public Long getTradeMode() {
        return tradeMode;
    }

    public void setTradeMode(Long tradeMode) {
        this.tradeMode = tradeMode;
    }
}