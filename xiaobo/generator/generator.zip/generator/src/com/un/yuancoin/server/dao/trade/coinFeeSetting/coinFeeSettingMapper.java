package com.un.yuancoin.server.dao.trade.coinFeeSetting;

import com.un.yuancoin.model.coinFeeSetting.coinFeeSetting;

public interface coinFeeSettingMapper {
    int deleteByPrimaryKey(Long id);

    int insert(coinFeeSetting record);

    int insertSelective(coinFeeSetting record);

    coinFeeSetting selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(coinFeeSetting record);

    int updateByPrimaryKey(coinFeeSetting record);
}