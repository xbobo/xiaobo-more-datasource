package com.un.yuancoin.server.dao.trade.tranDealOrder;

import com.un.yuancoin.model.tranDealOrder.TranDealOrder;

public interface TranDealOrderMapper {
    int deleteByPrimaryKey(Long id);

    int insert(TranDealOrder record);

    int insertSelective(TranDealOrder record);

    TranDealOrder selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TranDealOrder record);

    int updateByPrimaryKey(TranDealOrder record);
}