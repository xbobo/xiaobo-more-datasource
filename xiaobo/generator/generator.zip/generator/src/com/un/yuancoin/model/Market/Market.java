package com.un.yuancoin.model.Market;

import java.math.BigDecimal;
import java.util.Date;

public class Market {
    private Long id;

    private BigDecimal sourceCoinId;

    private BigDecimal targetCoinId;

    private BigDecimal tradeType;

    private BigDecimal price;

    private BigDecimal amount;

    private Date createdate;

    private Date updatedate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public BigDecimal getSourceCoinId() {
        return sourceCoinId;
    }

    public void setSourceCoinId(BigDecimal sourceCoinId) {
        this.sourceCoinId = sourceCoinId;
    }

    public BigDecimal getTargetCoinId() {
        return targetCoinId;
    }

    public void setTargetCoinId(BigDecimal targetCoinId) {
        this.targetCoinId = targetCoinId;
    }

    public BigDecimal getTradeType() {
        return tradeType;
    }

    public void setTradeType(BigDecimal tradeType) {
        this.tradeType = tradeType;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Date getUpdatedate() {
        return updatedate;
    }

    public void setUpdatedate(Date updatedate) {
        this.updatedate = updatedate;
    }
}