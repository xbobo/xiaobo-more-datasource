package com.un.yuancoin.server.dao.trade.coinSetting;

import com.un.yuancoin.model.coinSetting.CoinSetting;

public interface CoinSettingMapper {
    int deleteByPrimaryKey(Long id);

    int insert(CoinSetting record);

    int insertSelective(CoinSetting record);

    CoinSetting selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(CoinSetting record);

    int updateByPrimaryKey(CoinSetting record);
}