package com.un.yuancoin.model.tranEntrustOrder;

import java.math.BigDecimal;
import java.util.Date;

public class TranEntrustOrder {
    private Long id;

    private Long sourceFinanceAccountId;

    private Long tradeType;

    private Long tradeMode;

    private Long sourceCoinId;

    private Long targetCoinId;

    private BigDecimal entrustPrice;

    private BigDecimal entrustAmount;

    private BigDecimal balanceFee;

    private BigDecimal deductFee;

    private BigDecimal totalFee;

    private BigDecimal tradeAmount;

    private BigDecimal untradeAmount;

    private BigDecimal tradeTotalmoney;

    private BigDecimal tradeTotalamount;

    private Long orderStatus;

    private Date createdate;

    private Date updatedate;

    private String tranSequence;

    private Long targetFinanceAccountId;

    private Long accountId;

    private String accountName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSourceFinanceAccountId() {
        return sourceFinanceAccountId;
    }

    public void setSourceFinanceAccountId(Long sourceFinanceAccountId) {
        this.sourceFinanceAccountId = sourceFinanceAccountId;
    }

    public Long getTradeType() {
        return tradeType;
    }

    public void setTradeType(Long tradeType) {
        this.tradeType = tradeType;
    }

    public Long getTradeMode() {
        return tradeMode;
    }

    public void setTradeMode(Long tradeMode) {
        this.tradeMode = tradeMode;
    }

    public Long getSourceCoinId() {
        return sourceCoinId;
    }

    public void setSourceCoinId(Long sourceCoinId) {
        this.sourceCoinId = sourceCoinId;
    }

    public Long getTargetCoinId() {
        return targetCoinId;
    }

    public void setTargetCoinId(Long targetCoinId) {
        this.targetCoinId = targetCoinId;
    }

    public BigDecimal getEntrustPrice() {
        return entrustPrice;
    }

    public void setEntrustPrice(BigDecimal entrustPrice) {
        this.entrustPrice = entrustPrice;
    }

    public BigDecimal getEntrustAmount() {
        return entrustAmount;
    }

    public void setEntrustAmount(BigDecimal entrustAmount) {
        this.entrustAmount = entrustAmount;
    }

    public BigDecimal getBalanceFee() {
        return balanceFee;
    }

    public void setBalanceFee(BigDecimal balanceFee) {
        this.balanceFee = balanceFee;
    }

    public BigDecimal getDeductFee() {
        return deductFee;
    }

    public void setDeductFee(BigDecimal deductFee) {
        this.deductFee = deductFee;
    }

    public BigDecimal getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(BigDecimal totalFee) {
        this.totalFee = totalFee;
    }

    public BigDecimal getTradeAmount() {
        return tradeAmount;
    }

    public void setTradeAmount(BigDecimal tradeAmount) {
        this.tradeAmount = tradeAmount;
    }

    public BigDecimal getUntradeAmount() {
        return untradeAmount;
    }

    public void setUntradeAmount(BigDecimal untradeAmount) {
        this.untradeAmount = untradeAmount;
    }

    public BigDecimal getTradeTotalmoney() {
        return tradeTotalmoney;
    }

    public void setTradeTotalmoney(BigDecimal tradeTotalmoney) {
        this.tradeTotalmoney = tradeTotalmoney;
    }

    public BigDecimal getTradeTotalamount() {
        return tradeTotalamount;
    }

    public void setTradeTotalamount(BigDecimal tradeTotalamount) {
        this.tradeTotalamount = tradeTotalamount;
    }

    public Long getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Long orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Date getUpdatedate() {
        return updatedate;
    }

    public void setUpdatedate(Date updatedate) {
        this.updatedate = updatedate;
    }

    public String getTranSequence() {
        return tranSequence;
    }

    public void setTranSequence(String tranSequence) {
        this.tranSequence = tranSequence == null ? null : tranSequence.trim();
    }

    public Long getTargetFinanceAccountId() {
        return targetFinanceAccountId;
    }

    public void setTargetFinanceAccountId(Long targetFinanceAccountId) {
        this.targetFinanceAccountId = targetFinanceAccountId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName == null ? null : accountName.trim();
    }
}