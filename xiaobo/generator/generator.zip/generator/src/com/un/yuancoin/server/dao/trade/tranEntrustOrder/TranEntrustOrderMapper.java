package com.un.yuancoin.server.dao.trade.tranEntrustOrder;

import com.un.yuancoin.model.tranEntrustOrder.TranEntrustOrder;

public interface TranEntrustOrderMapper {
    int deleteByPrimaryKey(Long id);

    int insert(TranEntrustOrder record);

    int insertSelective(TranEntrustOrder record);

    TranEntrustOrder selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TranEntrustOrder record);

    int updateByPrimaryKey(TranEntrustOrder record);
}