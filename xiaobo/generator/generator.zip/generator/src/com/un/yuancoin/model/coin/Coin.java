package com.un.yuancoin.model.coin;

import java.util.Date;

public class Coin {
    private Long id;

    private String symbol;

    private String name;

    private String shortName;

    private String lable;

    private Short decimalDigit;

    private Long state;

    private Date createdate;

    private Date updatedate;

    private String rpcHost;

    private String rpcPort;

    private String rpcUser;

    private String rpcPwd;

    private Long isBit;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol == null ? null : symbol.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName == null ? null : shortName.trim();
    }

    public String getLable() {
        return lable;
    }

    public void setLable(String lable) {
        this.lable = lable == null ? null : lable.trim();
    }

    public Short getDecimalDigit() {
        return decimalDigit;
    }

    public void setDecimalDigit(Short decimalDigit) {
        this.decimalDigit = decimalDigit;
    }

    public Long getState() {
        return state;
    }

    public void setState(Long state) {
        this.state = state;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Date getUpdatedate() {
        return updatedate;
    }

    public void setUpdatedate(Date updatedate) {
        this.updatedate = updatedate;
    }

    public String getRpcHost() {
        return rpcHost;
    }

    public void setRpcHost(String rpcHost) {
        this.rpcHost = rpcHost == null ? null : rpcHost.trim();
    }

    public String getRpcPort() {
        return rpcPort;
    }

    public void setRpcPort(String rpcPort) {
        this.rpcPort = rpcPort == null ? null : rpcPort.trim();
    }

    public String getRpcUser() {
        return rpcUser;
    }

    public void setRpcUser(String rpcUser) {
        this.rpcUser = rpcUser == null ? null : rpcUser.trim();
    }

    public String getRpcPwd() {
        return rpcPwd;
    }

    public void setRpcPwd(String rpcPwd) {
        this.rpcPwd = rpcPwd == null ? null : rpcPwd.trim();
    }

    public Long getIsBit() {
        return isBit;
    }

    public void setIsBit(Long isBit) {
        this.isBit = isBit;
    }
}