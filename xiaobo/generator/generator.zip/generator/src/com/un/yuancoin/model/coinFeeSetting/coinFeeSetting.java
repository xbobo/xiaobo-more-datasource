package com.un.yuancoin.model.coinFeeSetting;

import java.math.BigDecimal;
import java.util.Date;

public class coinFeeSetting {
    private Long id;

    private Long coinId;

    private Date createdate;

    private Date updatedate;

    private Long type;

    private Long calMode;

    private BigDecimal feeValue;

    private Long confirmUserId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCoinId() {
        return coinId;
    }

    public void setCoinId(Long coinId) {
        this.coinId = coinId;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Date getUpdatedate() {
        return updatedate;
    }

    public void setUpdatedate(Date updatedate) {
        this.updatedate = updatedate;
    }

    public Long getType() {
        return type;
    }

    public void setType(Long type) {
        this.type = type;
    }

    public Long getCalMode() {
        return calMode;
    }

    public void setCalMode(Long calMode) {
        this.calMode = calMode;
    }

    public BigDecimal getFeeValue() {
        return feeValue;
    }

    public void setFeeValue(BigDecimal feeValue) {
        this.feeValue = feeValue;
    }

    public Long getConfirmUserId() {
        return confirmUserId;
    }

    public void setConfirmUserId(Long confirmUserId) {
        this.confirmUserId = confirmUserId;
    }
}