package com.un.yuancoin.server.dao.trade.coin;

import com.un.yuancoin.model.coin.Coin;

public interface CoinMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Coin record);

    int insertSelective(Coin record);

    Coin selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Coin record);

    int updateByPrimaryKey(Coin record);
}