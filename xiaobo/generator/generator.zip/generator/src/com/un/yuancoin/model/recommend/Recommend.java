package com.un.yuancoin.model.recommend;

import java.util.Date;

public class Recommend {
    private Long id;

    private Long refereeAccountId;

    private Long recommednAccountId;

    private Date createdate;

    private Date updatedate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRefereeAccountId() {
        return refereeAccountId;
    }

    public void setRefereeAccountId(Long refereeAccountId) {
        this.refereeAccountId = refereeAccountId;
    }

    public Long getRecommednAccountId() {
        return recommednAccountId;
    }

    public void setRecommednAccountId(Long recommednAccountId) {
        this.recommednAccountId = recommednAccountId;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Date getUpdatedate() {
        return updatedate;
    }

    public void setUpdatedate(Date updatedate) {
        this.updatedate = updatedate;
    }
}