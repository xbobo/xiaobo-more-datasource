package com.un.yuancoin.server.dao.trade.tranCancelOrder;

import com.un.yuancoin.model.tranCancelOrder.TranCancelOrder;

public interface TranCancelOrderMapper {
    int deleteByPrimaryKey(Long id);

    int insert(TranCancelOrder record);

    int insertSelective(TranCancelOrder record);

    TranCancelOrder selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TranCancelOrder record);

    int updateByPrimaryKey(TranCancelOrder record);
}