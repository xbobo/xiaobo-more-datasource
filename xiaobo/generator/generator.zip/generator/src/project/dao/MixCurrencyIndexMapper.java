package project.dao;

import project.model.MixCurrencyIndex;

public interface MixCurrencyIndexMapper {
    int deleteByPrimaryKey(Long id);

    int insert(MixCurrencyIndex record);

    int insertSelective(MixCurrencyIndex record);

    MixCurrencyIndex selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(MixCurrencyIndex record);

    int updateByPrimaryKey(MixCurrencyIndex record);
}