package project.dao;

import project.model.ReportData;

public interface ReportDataMapper {
    int deleteByPrimaryKey(Long id);

    int insert(ReportData record);

    int insertSelective(ReportData record);

    ReportData selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ReportData record);

    int updateByPrimaryKey(ReportData record);
}