package com.puxinwangxiao.erp.websocket.dto;

import lombok.Data;

@Data
public class QueryDTO {

	private String id;
}
